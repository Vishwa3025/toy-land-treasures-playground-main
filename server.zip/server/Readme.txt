To run Server side code :
1. cd server
2. npm install
3. npm run dev